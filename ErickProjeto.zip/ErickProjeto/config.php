<?php

    define("HOST", "localhost");
    define("USER", "root");
    define("PASS", "");
    define("BASE", "concessionaria2122n");

    $conn = new MYSQLi(HOST, USER, PASS, BASE);
